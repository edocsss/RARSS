Naming Convention of files: 
XYZAccel_(Date)_(...)

X: Activity Tag
Y: Pocket location
Z: Posture

In this project we only test for the activity tag recognition.