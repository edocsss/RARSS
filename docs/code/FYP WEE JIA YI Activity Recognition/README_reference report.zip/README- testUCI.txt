This folder contains the testing dataset used in UCI work.
It consists of 30% of the user profiles collected.

Files present in this folder is extracted from: 
https://archive.ics.uci.edu/ml/datasets/Human+Activity+Recognition+Using+Smartphones

Files in this folder is already formatted and adapted to the RARMT framework.