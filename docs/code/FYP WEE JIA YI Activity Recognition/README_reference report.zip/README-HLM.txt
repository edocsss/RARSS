This folder contains the HLM Testing data. 

you can copy paste the test cases_Xa_Y into the matlab SVM main folder for processing.